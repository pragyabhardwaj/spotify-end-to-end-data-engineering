import json
import os
import spotipy 
from spotipy.oauth2 import SpotifyClientCredentials
#import pandas as pd
import boto3
from datetime import datetime

def lambda_handler(event, context):
    # TODO implement
    client_id=os.environ.get("client_id")
    client_secret=os.environ.get("client_secret")
    
    client_credentials_manager=SpotifyClientCredentials(client_id=client_id,client_secret=client_secret)
    sp=spotipy.Spotify(client_credentials_manager=client_credentials_manager)
    
    playlist_link="https://open.spotify.com/playlist/4hOKQuZbraPDIfaGbM3lKI"
    playlist_list=playlist_link.split("/")
    
    playlist_uri=playlist_list[-1]
    #print(playlist_uri)
    
    data=sp.playlist_tracks(playlist_uri)
    #print(data)
    
    client=boto3.client('s3')
    filename="spotify_raw_"+str(datetime.now()) +".json"
    client.put_object(
        Bucket="my-aws-data-pipeline-project",
        Key="raw_data/to_processed/" +filename,
        Body=json.dumps(data)
        )
    
    # #Structure the data
    # album_id=data['items'][0]['track']['album']['id']
    # album_name=data['items'][0]['track']['album']['name']
    # album_release_date=data['items'][0]['track']['album']['release_date']
    # album_tracks=data['items'][0]['track']['album']['total_tracks']
    # album_external_url=data['items'][0]['track']['album']['external_urls']['spotify']

    # #print(album_id,album_name,album_release_date,album_tracks,album_external_url)
    
    # album_structured=[]
    # for row in data['items']:
    #     album_id=row['track']['album']['id']
    #     album_name=row['track']['album']['name']
    #     album_release_date=row['track']['album']['release_date']
    #     album_tracks=row['track']['album']['total_tracks']
    #     album_external_url=row['track']['album']['external_urls']['spotify']
    #     #print(album_id,album_name,album_release_date,album_tracks,album_external_url)
    #     album_element={'album_id':album_id,'album_name':album_name,'album_release_date':album_release_date,'album_tracks':album_tracks,
    #                   'album_external_url':album_external_url}
    #     album_structured.append(album_element)
    #     print(album_element)

    
